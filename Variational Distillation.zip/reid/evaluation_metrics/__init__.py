from __future__ import absolute_import

from .ranking import cmc, mean_ap

__all__ = [
    'cmc',
    'mean_ap',
]
